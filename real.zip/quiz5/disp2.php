<?php

$first = $_POST['Name'];
$x = $_POST['Fname'];
$second= $_POST['CA'];
$third=$_POST['Ap'];
$five=$_POST['bba'];
$six=$_POST['mba'];
$sev=$_POST['bscs'];
$eight=$_POST['mscs'];


if($_POST['group1'] == 'Name') 
{
echo Name;
}
?>