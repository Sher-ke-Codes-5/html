<!DOCTYPE html>


<html>
    <header>
<title> register form </title>
</header>
<body>
<form method="post" attribute="post" action="disp2.php" style="border: 2px solid black; background:green ">
<input type="text" placeholder="Name"  id="name"><br>
<input type="text" placeholder="Fname"  id="Fname"><br>
<input type="text" placeholder="Contact add" id="CA"><br>
<input type="text" placeholder="Addres Per"  id="Ap"><br>
<input type="text" placeholder="city"  id="name"><br>
<input type="radio" name="group1" id="bba" value="bba"><p>BBA </p><br/>
<input type="radio" name="group1" id="mba" value="mba"><p>MBA </p><br/>
<input type="radio" name="group1" id="bscs" value="bscs"><p>BSCS </p><br/>
<input type="radio" name="group1" id="mscs" value="mscs"><p>MSCS </p><br/>
<input type="checkbox" name="group1" id="sportgyman" value="sportgyman"><p>SPORTS </p><br/>
<input type="checkbox" name="group1" id="Bus" value="Bus"><p>BUS FACILTY </p><br/>
<input type="checkbox" name="group1" id="Hotel" value="Hotel"><p>HOTEL </p><br/>
<button type="submit" name="answer" id="answer" value="answer">submit</button>
</form>



</body>
